<script>
  export let slug;
</script>

<style>
  a {
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
</style>

<a href={`https://docs.turbowarp.org/${slug}`} title="Learn more" target="_blank" rel="noopener noreferrer">(?)</a>
