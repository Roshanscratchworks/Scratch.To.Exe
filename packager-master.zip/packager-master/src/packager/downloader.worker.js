import * as Comlink from 'comlink';
import downloadProject from './lib/download-project';

Comlink.expose({
  downloadProject
});
